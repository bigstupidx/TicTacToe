//
//  MPAdWebView.h
//  MoPub
//
//  Copyright (c) 2012 MoPub, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPAdWebView : UIWebView

@end
