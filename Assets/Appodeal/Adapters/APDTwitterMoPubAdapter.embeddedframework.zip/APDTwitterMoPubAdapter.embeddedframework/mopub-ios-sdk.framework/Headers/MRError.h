//
//  MRError.h
//  MoPubSDK
//
//  Copyright (c) 2014 MoPub. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString * const MoPubMRAIDAdsSDKDomain;

enum {
    MRErrorMRAIDJSNotFound
};
typedef NSInteger MRErrorCode;
